<?php
/*==========================================================
* 파일명 : adsync.php
* 작성자 : 마이티미디어 개발본부/기술지원팀 (dev@mightymedia.co.kr)
* 작성일 : 2013.02
* 수정일 : 2015.04
* 용  도 : 매체사의 앱사용자가 AdSync 서버에서 포인트 적립 완료 시 매체사 서버에서 포인트 전달 받을 경우 샘플

	로그인관련 쿠키나 세션값은 전달이 되지 않음
	(브라우저 호출이 아닌 서버간 호출로 일종의 포인트 전환 처리 데몬역할 페이지임)

	포인트정보를 받아서 매체사 서비스처리 부분 코딩 후 처리결과값을
*==========================================================*/

//매체사의 서비스 처리 관련 include  파일

//AdSync에서 매체사로 전달한 포인트 정보값을 확인할 경우에만 아래 주석을 해제해서 확인
/* error_log 로 저장하여 확인할 수 있다. */

// 2015.07.08 tonylee 로그 남기기 방법
$log_path = $_SERVER['DOCUMENT_ROOT']."/logs/"; // 로그 위치   ==> 절대경로

@mkdir($log_path);
@chmod($log_path, 0757);


$log_file_name = $log_path."adsync_".date('Ymd').".log"; //로그파일

// 이런 방법으로 해당 파라미터가 제대로 오는지 확인한다..
error_log("\r\n".date("Y-m-d H:i:s")." POST : ".json_encode($_POST) ,3,$log_file_name);

$partner	= $_POST['partner'];	// 파트너 앱(서비스) ID
$cust_id	= $_POST['cust_id'];	// 파트너 회원 ID
$ad_no		= $_POST['ad_no'];		// 적립 광고 번호
$seq_id		= $_POST['seq_id'];		// 포인트 적립 고유 ID
$point		= $_POST['point'];		// 적립 포인트
$ad_title	= $_POST['ad_title'];	// 적립 광고 제목
$valid_key	= $_POST['valid_key'];	// 유효성 확인 Key

// 서비스 처리 코딩 후 결과를 기본값
$arr_result = array('Result' => true , 'ResultCode' => 1 ,'ResultMsg' => "성공");

// 전달 받은 파라미터 체크 부분
if(empty($partner) || empty($cust_id) || empty($ad_no) || empty($point) || empty($seq_id) || empty($valid_key) || empty($ad_title)){
	//서비스 처리 코딩 후 결과를 JSON 형식으로 출력
	$arr_result['Result'] = false;
	$arr_result['ResultCode'] = 4;
	$arr_result['ResultMsg'] = "파라미터 오류";
	echo json_encode($arr_result);
	exit;
}

//적립포인트 수신에 대한 유효성 체크 부분
//유효성 확인키 생성: md5(발급받은인증키+서버로전달받은cust_id+서버로전달받은seq_id)
//생성한 유효성 확인키와 서버로전달받은 valid_key 검증
//AdSync로 부터 발급받은 인증키(파트너백오피스 혹은 메일로 발급 받은 인증키)
$issuedAuthKey = "";

$checkValidKey = md5($issuedAuthKey.$cust_id.$seq_id);
if($checkValidKey != $valid_key)
{
	//서비스 처리 코딩 후 결과를 JSON 형식으로 출력
	$arr_result['Result'] = false;
	$arr_result['ResultCode'] = 2;
	$arr_result['ResultMsg'] = "유효성 확인 key 오류";
	echo json_encode($arr_result);
	exit;
}


// 적립포인트 수신에 대한 중복 체크 처리 부분(단일 고유키키값 seq_id)
//서버로 전달받은 seq_id 값으로 기존 성공적으로 전달받은 seq_id 값이 있는지 DB 검사
//ex)성공적으로 전달받은 적립포인트정보내역 테이블: partner_point

$seq_cnt = 0;		// 0이상이면 증복이다.
if($seq_cnt != 0){
	$arr_result['Result'] = false;
	$arr_result['ResultCode'] = 3;
	$arr_result['ResultMsg'] = "중복 지급  오류";
	echo json_encode($arr_result);
	exit;
}

// 매체사 처리할 리워드 지급 ..


// 매체사 유저에게 리워드 지급 후 성공 Json string return >
//AdSync Noti 서버가 위의 JSON 응답값을 확인 ResultCode값을 Parsing 하여 관련 이력을 처리(AdSync 백오피스에서 확인 가능)
// "1"이 아닌 경우는 일일배치로 본페이지를 재호출함. 


$arr_result['Result'] = true;
$arr_result['ResultCode'] = 1;
$arr_result['ResultMsg'] = "success";

echo json_encode($arr_result);
exit;

?>