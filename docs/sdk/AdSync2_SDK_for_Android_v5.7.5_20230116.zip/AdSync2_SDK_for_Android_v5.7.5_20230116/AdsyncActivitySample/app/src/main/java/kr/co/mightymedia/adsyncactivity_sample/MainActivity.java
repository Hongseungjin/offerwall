package kr.co.mightymedia.adsyncactivity_sample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.fpang.lib.FpangSession;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button adsyncBtn = (Button)findViewById(R.id.btn_show_adsync);

        adsyncBtn.setOnClickListener( adsyncBtnListner );

        FpangSession.init( this );
        FpangSession.setDebug( true ); // 배포시 false 로 설정
        FpangSession.setUserId("youruserId"); // 사용자 ID 설정
        //추가 정보 설정(options)
        FpangSession.setAge(25); // 0 이면 값없음
        FpangSession.setGender("M"); // M:남자, F:여자, A:값없음
        //FpangSession.setCloseBtn(R.drawable.close_ic);

    }

    View.OnClickListener adsyncBtnListner = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            // Activity 일 경우.
            FpangSession.showAdsyncList(MainActivity.this, "무료충전소");
            // Fragment 일 경우
            // FpangSession.showAdsyncFragment(MainActivity.this, R.id.fragment_adsync, "AdSync2");
        }
    };
}
