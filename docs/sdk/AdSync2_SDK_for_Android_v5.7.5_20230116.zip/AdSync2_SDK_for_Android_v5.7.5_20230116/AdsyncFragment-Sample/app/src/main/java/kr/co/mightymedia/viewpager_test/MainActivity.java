package kr.co.mightymedia.viewpager_test;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends FragmentActivity {

    ViewPager2 vp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vp = (ViewPager2)findViewById(R.id.vp);
        Button btn_first = (Button)findViewById(R.id.btn_first);
        Button btn_second = (Button)findViewById(R.id.btn_second);
        Button btn_third = (Button)findViewById(R.id.btn_third);

        vp.setAdapter(new pagerAdapter(this));
        vp.setCurrentItem(0);

        btn_first.setOnClickListener(movePageListner);
        btn_first.setTag(0);
        btn_second.setOnClickListener(movePageListner);
        btn_second.setTag(1);
        btn_third.setOnClickListener(movePageListner);
        btn_third.setTag(2);

    }

    View.OnClickListener movePageListner = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int tag = (int) view.getTag();
            vp.setCurrentItem(tag);
        }
    };

    private class pagerAdapter extends FragmentStateAdapter {
        public pagerAdapter(FragmentActivity fa) {

            super(fa);
        }
        @Override
        public Fragment createFragment(int position) {
            switch (position) {
                case 0:
                    return new FirstFragment();
                case 1:
                    return new SecondFragment();
                case 2:
                    return new ThirdFragment();
                default:
                    return null;
            }
        }
        @Override
        public int getItemCount() {
            return 3;
        }
    }
}
