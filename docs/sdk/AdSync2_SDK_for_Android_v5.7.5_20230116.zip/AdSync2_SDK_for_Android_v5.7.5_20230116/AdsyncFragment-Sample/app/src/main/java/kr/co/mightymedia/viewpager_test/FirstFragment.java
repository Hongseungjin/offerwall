package kr.co.mightymedia.viewpager_test;

import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.fpang.lib.FpangSession;

public class FirstFragment extends Fragment {
    public FirstFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        RelativeLayout layout = (RelativeLayout) inflater.inflate(R.layout.fragment_first, container, false);
        Handler handler = new Handler();

        FpangSession.init(getActivity());
        FpangSession.setDebug(true);
        FpangSession.setUserId("customId");

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                FpangSession.showAdSyncFragment(getActivity(), R.id.fragment_adsync, "Adsync2");
            }
        }, 3000);

        return layout;
    }
}
